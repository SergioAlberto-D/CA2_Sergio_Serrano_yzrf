package mx.edu.utez.support.controller;

import java.util.List;
import mx.edu.utez.support.dto.TicketResponseDTO;
import mx.edu.utez.support.service.TicketService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketService service;

    public TicketController(TicketService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<TicketResponseDTO>> findAll() {
        return ResponseEntity.ok(service.findAll());
    }

    // Las operaciones solicitadas durante la evaluacion se implementan aqui.
}

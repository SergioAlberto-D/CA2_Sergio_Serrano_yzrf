package mx.edu.utez.support.service;

import java.util.List;
import mx.edu.utez.support.dto.TicketResponseDTO;
import mx.edu.utez.support.repository.TicketRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketService {

    private final TicketRepository repository;

    public TicketService(TicketRepository repository) {
        this.repository = repository;
    }

    public List<TicketResponseDTO> findAll() {
        return repository.findAll().stream()
                .map(TicketResponseDTO::fromEntity)
                .toList();
    }

    // Las operaciones solicitadas durante la evaluacion se implementan aqui.
}
